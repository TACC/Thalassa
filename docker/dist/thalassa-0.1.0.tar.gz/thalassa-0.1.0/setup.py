# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['thalassa']

package_data = \
{'': ['*'], 'thalassa': ['static/*', 'templates/*']}

install_requires = \
['bokeh>=2.2.3,<3.0.0',
 'datashader>=0.11.1,<0.12.0',
 'geoviews>=1.8.1,<2.0.0',
 'holoviews>=1.14.0,<2.0.0',
 'hvplot>=0.7.0,<0.8.0',
 'llvmlite<=0.34',
 'matplotlib>=3.3.3,<4.0.0',
 'netCDF4>=1.5.5,<2.0.0',
 'numpy>=1.19.4,<2.0.0',
 'pandas>=1.1.5,<2.0.0',
 'panel>=0.10.2,<0.11.0',
 'pyproj>=3.0.0,<4.0.0',
 'scipy>=1.5.4,<2.0.0',
 'typer>=0.3.2,<0.4.0',
 'xarray>=0.16.2,<0.17.0']

entry_points = \
{'console_scripts': ['thalassa = thalassa.cli:app']}

setup_kwargs = {
    'name': 'thalassa',
    'version': '0.1.0',
    'description': 'Visualization of large scale results of hydrodynamic simulations',
    'long_description': "Large Scale Sea level visualizations of unstructured mesh data\n===============================================================\n\nThis is a developmental prototype for visualizing large scale results of hydrodynamic simulations.\n\nThalassa is powered by\n\n- [pyPoseidon](https://github.com/ec-jrc/pyPoseidon)\n\n- [SCHISM](https://github.com/schism-dev/schism)\n\n- [Panel](https://panel.holoviz.org/index.html)\n\n## Instalation\n\nStart by cloning the repository:\n\n### Option 1: Use a virtualenv\n\nYour system needs to have:\n\n- python>=3.8\n- geos\n- gdal=3.2.1\n- proj `<8`\n- poetry\n\nThere are multiple ways to satisfy these requirements, e.g. using your distro's package manager,\ncompiling from source, etc. An easy way to proceed is to create a conda environment like the\nfollowing:\n\n```\nconda create -n Thalassa pip python=3.8 geos gdal=3.2.1 proj=7 poetry\n```\n\nAfterwards, activate the new conda environment, create a virtualenv and install the dependencies using\npoetry:\n\n```\nconda activate Thalassa\npython3 -m venv .venv\nsource .venv/bin/activate\npoetry install\n```\n\nYou are ready to go!\n\n### Option 2: Use conda\n\nInstall the dependencies in a conda environment with:\n\n```\nconda env create -f binder/environment.yml\n```\n\n### Option3: Use docker\n\n```\ndocker/build.sh\n```\n\nThis will create a docker image\n\n## Obtaining Data\n\nYou will need some data. If you don't have any you can download a sample dataset from here:\n\n```\nwget -O data/animation.mp4 https://static.techrad.eu/thalassa/animation.mp4\nwget -O data/dataset.nc    https://static.techrad.eu/thalassa/dataset.nc\nwget -O data/stations.csv  https://static.techrad.eu/thalassa/stations.csv\nwget -O data/stations.zip  https://static.techrad.eu/thalassa/stations.zip\nwget -O data/thalassa.png  https://static.techrad.eu/thalassa/thalassa.png\n```\n\n## Running Thalassa\n\n### Conda or virtualenv\n\nIf you used conda or virtualenv, you can launch the Thalassa web server with:\n\n```\nthalassa serve --websocket-origin='localhost:9000' --port 9000\n```\n\nAn image should open on your visit http://localhost:9000\n\n### Conda\n\nIf you used conda you can also use:\n\n```\npanel serve --show Thalassa.ipynb\n```\n\nit will open in your default browser.\n\n### docker\n\nIf you build the docker image, execute:\n\n```\ndocker/run.sh\n```\n\nThis will start a webserver listening on port 61112. So visit: http://localhost:61112\n\n**NOTE**: If you want to deploy this on a server, you will probably want to change the\n`websocket-origin` in `docker/run.sh` to something more secure (e.g. to a subdomain).\n\n## License\n* The project is released under the EUPL v1.2 license.\n",
    'author': 'Panos Mavrogiorgos',
    'author_email': 'pmav99@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/brey/Thalassa',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
